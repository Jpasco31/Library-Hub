
function scrollToBookPage() {
    const bookPageElement = document.getElementById('bookpage');
    if (bookPageElement) {
        bookPageElement.scrollIntoView({ behavior: 'smooth' });
    }
}

function myFunction() {
    alert("Not admin");
  }

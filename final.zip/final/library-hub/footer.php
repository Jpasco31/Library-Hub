<?php
    echo '<footer class="p-4 bg-dark text-white text-center position-relative opacity-50">
    <p class="lead fs-6">Copyright &copy; 2023 Library Management System. All rights reserved.</p>
</footer>';

?>
How to run:
1. Extract zip folder "final"
2. Put "final" folder to htdocs
4. Activate xampp
    -open xampp
    -go to manage servers
    -start mysql database and apache web server
3. Import library-hub.sql
    - Create a database in xampp - localhost
    - name it "library-hub"
    - import the "libray-hub.sql" file in the created database

4. In browser
    -type "localhost/final/library-hub.php"

5. To access the website in login
Username:	Password:	Account Type:
admin	    admin    	admin
jasper      jasper      user 
kristina    kristina    user

6. Alternative
    -Sign up a new Account

7. Enjoy!